package com.example.photogallery;

public class RequestCode {
    // Request codes here
    public static int SEARCH_ACTIVITY_REQUEST_CODE = 0;
    public static int CAMERA_REQUEST_CODE = 1;

    public static int REQUEST_READ_PHONE_STATE_PERMISSION = 1;
}
