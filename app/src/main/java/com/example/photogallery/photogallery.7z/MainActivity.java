package com.example.photogallery;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.BitmapFactory;
import android.location.Address;
import android.location.Geocoder;
import android.media.ExifInterface;
import android.net.Uri;
import android.os.Environment;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{
    private int currentPhotoIndex = 0;  // default to first picture
    private ArrayList<String> photoGallery;
    private String userLocationTag = "Italy";

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.default_activity);

        // Check for runtime permissions
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, RequestCode.REQUEST_READ_PHONE_STATE_PERMISSION);
        } else {
            try {
                photoGallery = fillGallery(userLocationTag); // Otherwise, permission already granted
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        if (photoGallery.size() > 0) {
            try {
                displayPhoto(photoGallery.get(currentPhotoIndex));
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        // Button listeners
        Button btnLeft = (Button) findViewById(R.id.btnLeft);
        Button btnRight = (Button) findViewById(R.id.btnRight);
        Button btnSearch = (Button) findViewById(R.id.btnSearch);
        Button btnSnap = (Button) findViewById(R.id.btnSnap);

        // Left and right handled by default onClick
        btnLeft.setOnClickListener(this);
        btnRight.setOnClickListener(this);

        // 'Search' and 'Snap' has custom handlers
        btnSearch.setOnClickListener(searchListener);


    }

    // Display photo
    private void displayPhoto(String path) throws IOException {
        ImageView iv = findViewById(R.id.selectedImage);
        iv.setImageBitmap((BitmapFactory.decodeFile(path)));

        TextView locationShort = (TextView) findViewById(R.id.locationShort);

        // Get the path
        String currentPhotoPath = photoGallery.get(currentPhotoIndex);
        ExifInterface currentExif = new ExifInterface(currentPhotoPath);

        // Get latLong
        float[] latLong = new float[2];

        // Translate into address
        Geocoder geo = new Geocoder(MainActivity.this.getApplicationContext(), Locale.getDefault());
        List<Address> addresses = geo.getFromLocation(latLong[0], latLong[1], 1);

        locationShort.setText(addresses.get(0).getLocality() + ", " + addresses.get(0).getCountryName());
    }

    // 'Search' handler navigates to 'Search' activity
    private View.OnClickListener searchListener = new View.OnClickListener() {
        public void onClick(View v) {
            Intent i = new Intent(MainActivity.this, SearchActivity.class);
            startActivityForResult(i, RequestCode.SEARCH_ACTIVITY_REQUEST_CODE);
        }
    };

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == RequestCode.SEARCH_ACTIVITY_REQUEST_CODE) {
            if (resultCode == Activity.RESULT_CANCELED) {

            }
        }
    }

    public void onClick(View v) {
        // Iterate photos
        if (v.getId() == R.id.btnLeft && currentPhotoIndex > 0)
            --currentPhotoIndex;
        else if (v.getId() == R.id.btnRight && currentPhotoIndex < (photoGallery.size()-1))
            ++currentPhotoIndex;

        // Display photos
        try {
            displayPhoto(photoGallery.get(currentPhotoIndex));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // TODO: add date arguments
    private ArrayList<String> fillGallery(String userLocTag) throws IOException {
        // Storage path
        File galleryPath = new File("/storage/emulated/0/DCIM/Camera");
        ArrayList<String> filledGallery = new ArrayList<>();

        ExifInterface currentExif;

        float[] latLong = new float[2];

        // Fill gallery with photos from path
        if (galleryPath.listFiles() != null) {

            // If no location tags are input
            if (userLocTag == null) {
                for (File photo : galleryPath.listFiles()) {
                    filledGallery.add(photo.getPath());
                }
            } else {
                for (File photo : galleryPath.listFiles()) {
                    // Get file path
                    currentExif = new ExifInterface(photo.getPath());
                    currentExif.getLatLong(latLong);

                    // Convert to location
                    Geocoder geo = new Geocoder(MainActivity.this.getApplicationContext(), Locale.getDefault());
                    List<Address> addresses = geo.getFromLocation(latLong[0], latLong[1], 1);

                    // Check if tags match
                    if (addresses.get(0).getCountryName().equals(userLocTag)) {
                        filledGallery.add(photo.getPath());
                    }
                }
            }
        }
        return filledGallery;
    }
}
