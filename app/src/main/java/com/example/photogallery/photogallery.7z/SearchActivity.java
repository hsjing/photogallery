package com.example.photogallery;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class SearchActivity extends AppCompatActivity implements View.OnClickListener {

    // Variables
    private EditText fromDate;
    private EditText toDate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.search_activity);

        // Buttons
        Button fromDateBtn = (Button) findViewById(R.id.fromDateBtn);
        Button toDateBtn = (Button) findViewById(R.id.toDateBtn);
        Button locationBtn = (Button) findViewById(R.id.locationBtn);

        Button searchBtn = (Button) findViewById(R.id.searchBtn);
        Button backBtn = (Button) findViewById(R.id.backBtn);

        fromDateBtn.setOnClickListener(fromDateListener);
        toDateBtn.setOnClickListener(toDateListener);
        locationBtn.setOnClickListener(locListener);

        searchBtn.setOnClickListener(this);
        backBtn.setOnClickListener(this);
    }

    // Search and back buttons
    public void onClick(View v) {
        if (v.getId() == R.id.searchBtn) {

        } else if (v.getId() == R.id.backBtn) {
            // Finish startActivityForResult callback
            Intent returnIntent = new Intent();
            setResult(Activity.RESULT_CANCELED, returnIntent);
            finish();
        }
    }


    // Listener handler opens up date selector
    private View.OnClickListener fromDateListener = new View.OnClickListener() {
        public void onClick(View v) {

        }
    };

    private View.OnClickListener toDateListener = new View.OnClickListener() {
        public void onClick(View v) {

        }
    };

    // Listener handles location selection
    private View.OnClickListener locListener = new View.OnClickListener() {
        public void onClick(View v) {

        }
    };

}
